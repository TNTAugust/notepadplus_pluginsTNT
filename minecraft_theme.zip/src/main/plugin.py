import handler.main as npp
import handler.log as log
import handler.config as config
from tkinter import *
import os

def single_player():
    os.system("start https://classic.minecraft.net/")
def lifeserver():
    os.system("start http://lifeserverf.org/")
npp.color_background("#0DAB00")
npp.color_foreground("#0023FF")
npp.color_blinker("black")

npp.set_custom_action ("Singleplayer",single_player)
npp.set_custom_gui ("Lifeserver",lifeserver)
npp.main() 